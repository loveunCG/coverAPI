<h1>Easy Cover! </h1>
<br>
 <h1>Verificaton Code: <strong>{{$user['verifyToken']}}</strong></h1>
